<div class="heading">
  <div class="logo">
    Assignment 3
  </div>
</div>