<div class="footer">
  <ul class="footer__sitemap">
    <li class="footer__sitemap-element">
      Assignment 3
      <ul class="footer__sub-sitemap">
        <li class="footer__sub-sitemap-element">
          <a href="./index.php">View All Course</a>
        </li>
        <li class="footer__sub-sitemap-element">
          <a href="./create.php"> Create Student</a>
        </li>
      </ul>
    </li>
    <li class="footer__site-map-element">GitHub
      <ul class="footer__sub-sitemap">
        <li class="footer__sub-sitemap-element">
          <a href="https://github.com/rmit-wp-s2-20222/s3766338-a3">Repository</a>
        </li>
      </ul>
    </li>
  </ul>
</div>